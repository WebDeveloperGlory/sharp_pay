// const getCoinRoute = require("../routes/getcoins/index");
// const getUserInfoRoute = require("../routes/get-account-details/index");
// const addBankAcc = require("../routes/addBankAccount/index");
// const setPasscode = require("../routes/setPasscode/index");
// const passcodeSignin = require("../routes/passcodeSignIn//index");
// const sellCoin = require("../routes/sellCoin/index");
// const buycoin = require("../routes/buyCoin/index");
// const buySellHistory = require("../routes/buySellHistory/index");

// module.exports = {
//     getCoinRoute,
//     getUserInfoRoute,
//     addBankAcc,
//     setPasscode,
//     passcodeSignin,
//     sellCoin,
//     buycoin,
//     buySellHistory
// }